export const backendUrlLogin = `http://localhost:4000/wanderlust/userAPI/userLogin`;

export const backendUrlRegister = `http://localhost:4000/wanderlust/userAPI/userRegister`;

export const backendUrlHotDeal = `http://localhost:4000/wanderlust/packageAPI/getPackages`;

export const backendUrlPackageSearch = `http://localhost:4000/wanderlust/packageAPI/packages`;

export const backendUrlBook = `http://localhost:4000/wanderlust/bookingAPI/bookings`;

export const backendUrlItinerary = `http://localhost:4000/wanderlust/packageAPI/itinerary`;

export const backendUrlViewBook = `http://localhost:4000/wanderlust/bookingAPI/`;

export const backendUrlDeleteBook = `http://localhost:4000/wanderlust/bookingAPI/bookings/`;

