package com.app.appException;

public class AppException extends Exception
{
	public AppException(String msg)
	{
		super(msg);
	}

}
