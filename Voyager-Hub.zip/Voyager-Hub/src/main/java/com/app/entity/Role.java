package com.app.entity;

public enum Role 
{
	Admin,Customer;

}
