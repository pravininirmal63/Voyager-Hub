package com.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entity.Routes;

public interface RoutesRepository extends JpaRepository<Routes, Long> {

}
